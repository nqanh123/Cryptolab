import utils

def generate_key(modulus_length):
    prime_length = modulus_length // 2

    # public exponent
    e = 3

    # generate first prime number
    p = 4
    while (p - 1) % e == 0:
        p = utils.generate_prime(prime_length)

    # generate second prime number
    q = p
    while q == p or (q - 1) % e == 0:
        q = utils.generate_prime(prime_length)

    n = p * q
    phi = (p - 1) * (q - 1)

    d = utils.modinv(e, phi)

    public_key = (n, e)
    secret_key = (n, d)

    print("Plublic key is: " + str(public_key))
    print("Secret key is: " + str(secret_key))
    with open("../Mission3/publickey.txt", "w") as file:
        file.write(str(n)+"\n"+str(e))
    with open("../Mission3/privatekey.txt", "w") as file:
        file.write(str(n)+"\n"+str(d))
    with open("../Mission4/publickey.txt", "w") as file:
        file.write(str(n)+"\n"+str(e))
    with open("../Mission4/privatekey.txt", "w") as file:
        file.write(str(n)+"\n"+str(d))
    print("----------")
    print("Exporting public key, secret key file is done!\nYou can check file txt in mission3")

generate_key(256)


