import utils
import ast

def encrypt_integer(public_key, m):
    (n, e) = public_key
    # print(public_key)
    if m > n:
        raise ValueError("Message is to big for current RSA scheme!")

    return pow(m, e, n)

def encrypt_string(public_key, message):
    # print(message)
    integer = utils.bytes_to_integer(message)
    # print(integer)
    enc_integer = encrypt_integer(public_key, integer)
    enc_string = utils.integer_to_bytes(enc_integer)

    return enc_string



print("Enter n, e, padding message after mission1 line by line:")
n = input()
e = input()
message = input()
str = encrypt_string((int(n), int(e)), eval('b\''+message+'\''))
print(str)
with open("../Mission3/paddingtext_file.txt", "wb") as file:
    file.write(str)
with open("../Mission4/paddingtext_file.txt", "wb") as file:
    file.write(str)
print("----------")
print("Exporting encoded message in binary code is done!\nYou can check file paddingtext_file.txt in mission3")
