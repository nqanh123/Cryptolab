import rsa
import utils

import os
import random
import time
from collections import namedtuple

modulus_size = 256
k = modulus_size // 8

t_start = time.perf_counter()

with open("./privatekey.txt", "r") as pri_file:
    n, d = map(int, pri_file.read().splitlines())
sk = (n, d)

global queries
queries = 0

def get_queries():
    global queries
    return queries

def oracle(ciphertext):
    """
    Placeholder for some server which talks RSA PKCS1 v1.5
    It can be used as an oracle, because it tells whether
    the given ciphertext decodes to a valid PKCS1 v1.5 encoding scheme,
    i.e. first 2 bytes of the plaintext == "\x00\x02"
    """
    global queries

    queries += 1
    t = time.perf_counter()
    if queries % 500 == 0:
        print("Query #{} ({} s)".format(queries, round(t - t_start, 3)))

    encoded = rsa.decrypt_string(sk, ciphertext)

    if len(encoded) > k:
        raise Exception("Invalid PKCS1 encoding after decryption!")

    if len(encoded) < k:
        zero_pad = b"\x00" * (k - len(encoded))
        encoded = zero_pad + encoded

    # return True
    return encoded[0:2] == b"\x00\x02"

def PKCS1_decode(encoded):
    """
    Decodes a PKCS1 v1.5 string.
    Remove constant bytes and random pad until arriving at "\x00".
    The rest is the message.
    """

    encoded = encoded[2:]
    idx = encoded.index(b"\x00")

    message = encoded[idx + 1 :]

    return message